import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './DataPages.css';

function CalendarPage({ user, token }) {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filterType, setFilterType] = useState('all');

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    setLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const res = await axios.get('http://localhost:3001/api/vehicles', { headers });
      
      let allServices = [];
      
      // Sbírám všechny servisní údaje ze všech vozidel
      for (const vehicle of res.data) {
        const detail = await axios.get(`http://localhost:3001/api/vehicles/${vehicle.id}`, { headers });
        detail.data.services.forEach(service => {
          allServices.push({
            vehicleSpz: vehicle.spz,
            vehicleBrand: vehicle.brand,
            vehicleModel: vehicle.model,
            ...service
          });
        });
      }
      
      // Seřadím podle data
      allServices.sort((a, b) => new Date(a.nextDue) - new Date(b.nextDue));
      setServices(allServices);
    } catch (error) {
      console.error('Chyba při načítání', error);
    } finally {
      setLoading(false);
    }
  };

  const getServiceIcon = (type) => {
    switch(type) {
      case 'STK': return '✅';
      case 'Pojištění': return '🛡️';
      case 'Přezutí': return '🛞';
      case 'Olej': return '🛢️';
      default: return '🔧';
    }
  };

  const getDaysUntil = (date) => {
    return Math.ceil((new Date(date) - new Date()) / (1000 * 60 * 60 * 24));
  };

  const getStatusColor = (daysUntil) => {
    if (daysUntil < 0) return '#dc3545'; // Červená - po termínu
    if (daysUntil <= 7) return '#ff9500'; // Oranžová - kritické
    if (daysUntil <= 30) return '#f39c12'; // Oranžová - warning
    return '#27ae60'; // Zelená - OK
  };

  const filtered = filterType === 'all' 
    ? services 
    : services.filter(s => s.type === filterType);

  const types = ['STK', 'Pojištění', 'Přezutí', 'Olej', 'Servis'];

  return (
    <div className="page">
      <h1>📅 Kalendář servisů</h1>

      {loading ? (
        <p>Načítám...</p>
      ) : (
        <>
          <div className="controls">
            <select value={filterType} onChange={(e) => setFilterType(e.target.value)} className="filter-select">
              <option value="all">Všechny servisní údaje</option>
              {types.map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {filtered.length === 0 ? (
              <p style={{ color: '#666', textAlign: 'center', padding: '40px' }}>
                Žádné servisní údaje nenalezeny
              </p>
            ) : (
              filtered.map((service, idx) => {
                const daysUntil = getDaysUntil(service.nextDue);
                const statusColor = getStatusColor(daysUntil);

                return (
                  <div
                    key={idx}
                    style={{
                      background: 'white',
                      padding: '15px',
                      borderRadius: '8px',
                      borderLeft: `4px solid ${statusColor}`,
                      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center'
                    }}
                  >
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '8px' }}>
                        {getServiceIcon(service.type)} <strong>{service.vehicleSpz}</strong> - {service.vehicleBrand} {service.vehicleModel}
                      </div>
                      <div style={{ fontSize: '14px', color: '#666' }}>
                        <strong>{service.type}</strong> do {new Date(service.nextDue).toLocaleDateString('cs-CZ')}
                      </div>
                      {service.provider && (
                        <div style={{ fontSize: '12px', color: '#999' }}>
                          Poskytovatel: {service.provider}
                        </div>
                      )}
                    </div>

                    <div
                      style={{
                        textAlign: 'center',
                        fontSize: '18px',
                        fontWeight: 'bold',
                        color: statusColor,
                        minWidth: '80px'
                      }}
                    >
                      {daysUntil < 0 ? (
                        <>
                          <div style={{ color: '#dc3545' }}>⚠️ PO TERMÍNU</div>
                          <div style={{ fontSize: '12px' }}>{Math.abs(daysUntil)} dní</div>
                        </>
                      ) : daysUntil === 0 ? (
                        <div>🔴 DNES!</div>
                      ) : (
                        <>
                          <div>{daysUntil} dní</div>
                        </>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default CalendarPage;
