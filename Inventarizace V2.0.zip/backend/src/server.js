require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const config = require('./config');
const Logger = require('./logger');
const { errorHandler, AppError } = require('./errorHandler');
const { initDatabase } = require('./database');

const logger = new Logger('Server');
const app = express();

// ============================================
// MIDDLEWARE SETUP
// ============================================

// CORS - bezpečné nastavení
app.use(cors({
  origin: config.cors.origin,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parser
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Static files - uploads
if (!fs.existsSync(config.upload.dir)) {
  fs.mkdirSync(config.upload.dir, { recursive: true });
  logger.info('✅ Created uploads directory');
}
app.use('/uploads', express.static(config.upload.dir));

// Request logging
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.path}`);
  next();
});

// ============================================
// ROUTES
// ============================================

const authRoutes = require('./routes/auth');
const contractsRoutes = require('./routes/contracts');
const vehiclesRoutes = require('./routes/vehicles');
const assetsRoutes = require('./routes/assets');

app.use('/api/auth', authRoutes);
app.use('/api/contracts', contractsRoutes);
app.use('/api/vehicles', vehiclesRoutes);
app.use('/api/assets', assetsRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date(),
    uptime: process.uptime()
  });
});

// ============================================
// 404 HANDLER
// ============================================

app.use((req, res) => {
  throw new AppError(`Route ${req.path} not found`, 404);
});

// ============================================
// GLOBAL ERROR HANDLER
// ============================================

app.use(errorHandler);

// ============================================
// SERVER START
// ============================================

const startServer = async () => {
  try {
    // Inicializuj databázi
    await initDatabase();
    logger.info('✅ Database initialized');

    // Spusť server
    app.listen(config.server.port, config.server.host, () => {
      logger.info(`🚀 Backend running on http://${config.server.host}:${config.server.port}`);
      logger.info(`📊 Environment: ${config.server.nodeEnv}`);
      logger.info(`📁 Upload directory: ${config.upload.dir}`);
    });
  } catch (error) {
    logger.error('Failed to start server', error);
    process.exit(1);
  }
};

startServer();

// ============================================
// GRACEFUL SHUTDOWN
// ============================================

process.on('SIGTERM', () => {
  logger.warn('SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.warn('SIGINT received, shutting down gracefully...');
  process.exit(0);
});

module.exports = app;

