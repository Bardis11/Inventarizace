const Logger = require('./logger');
const logger = new Logger('ErrorHandler');

/**
 * AppError - Custom error třídy
 */
class AppError extends Error {
  constructor(message, statusCode = 500) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;

    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Error middleware - centralizované error handling
 */
const errorHandler = (err, req, res, next) => {
  err.statusCode = err.statusCode || 500;
  err.message = err.message || 'Internal Server Error';

  // Loguj error
  logger.error(`${err.statusCode} - ${err.message}`, {
    path: req.path,
    method: req.method,
    error: err.message
  });

  // Pokud je to AppError - pošli error response
  if (err.isOperational) {
    return res.status(err.statusCode).json({
      success: false,
      error: err.message,
      statusCode: err.statusCode
    });
  }

  // Neznámá chyba - neposílej detaily
  res.status(500).json({
    success: false,
    error: 'Something went wrong',
    statusCode: 500
  });
};

/**
 * Async wrapper - catch chyby z async handlerů
 */
const asyncHandler = (fn) => {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
};

module.exports = {
  AppError,
  errorHandler,
  asyncHandler
};
