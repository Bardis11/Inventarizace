/**
 * Sanitizace stringů - ochrany proti XSS
 */
function sanitizeString(str) {
  if (typeof str !== 'string') return '';
  
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .trim()
    .substring(0, 500); // Max 500 znaků
}

/**
 * Validace emailu
 */
function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(sanitizeString(email));
}

/**
 * Validace data (YYYY-MM-DD)
 */
function validateDate(date) {
  if (!date) return false;
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(date)) return false;
  
  const d = new Date(date);
  return d instanceof Date && !isNaN(d);
}

/**
 * Validace čísla
 */
function validateNumber(num, min = 0, max = Infinity) {
  const n = parseFloat(num);
  return !isNaN(n) && n >= min && n <= max;
}

/**
 * Validace SPZ (CZ: ABC-1234)
 */
function validateSPZ(spz) {
  const spzRegex = /^[A-Z]{3}-\d{4}$/;
  return spzRegex.test(sanitizeString(spz));
}

/**
 * Validace UUID
 */
function validateUUID(uuid) {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
}

/**
 * Validace požadovaných polí
 */
function validateRequired(obj, fields) {
  const missing = [];
  
  fields.forEach(field => {
    if (!obj[field] || (typeof obj[field] === 'string' && !obj[field].trim())) {
      missing.push(field);
    }
  });

  return {
    valid: missing.length === 0,
    missing
  };
}

module.exports = {
  sanitizeString,
  validateEmail,
  validateDate,
  validateNumber,
  validateSPZ,
  validateUUID,
  validateRequired
};
