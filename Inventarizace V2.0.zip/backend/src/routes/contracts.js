const express = require('express');
const router = express.Router();
const { v4: uuid } = require('uuid');
const { getDb } = require('../database');
const authRoutes = require('./auth');

const verifyToken = authRoutes.verifyToken;
const requireRole = authRoutes.requireRole;

// GET všechny smlouvy (jen pro admin a smlouvy role)
router.get('/', verifyToken, (req, res) => {
  if (!['admin', 'smlouvy'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Nemáš oprávnění vidět smlouvy' });
  }

  const db = getDb();
  const { status, search } = req.query;

  let query = 'SELECT * FROM contracts WHERE 1=1';
  const params = [];

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  if (search) {
    query += ' AND (name LIKE ? OR counterparty LIKE ?)';
    params.push(`%${search}%`, `%${search}%`);
  }

  query += ' ORDER BY endDate ASC';

  db.all(query, params, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    // Přidej days until expiration
    const contracts = rows.map(contract => ({
      ...contract,
      daysUntilExpiration: Math.ceil((new Date(contract.endDate) - new Date()) / (1000 * 60 * 60 * 24)),
      severity: calculateSeverity(new Date(contract.endDate))
    }));

    res.json(contracts);
  });
});

// GET detail smlouvy
router.get('/:id', verifyToken, (req, res) => {
  if (!['admin', 'smlouvy'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Nemáš oprávnění' });
  }

  const db = getDb();
  db.get('SELECT * FROM contracts WHERE id = ?', [req.params.id], (err, row) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (!row) {
      return res.status(404).json({ error: 'Smlouva nenalezena' });
    }

    row.daysUntilExpiration = Math.ceil((new Date(row.endDate) - new Date()) / (1000 * 60 * 60 * 24));
    row.severity = calculateSeverity(new Date(row.endDate));

    res.json(row);
  });
});

// POST nová smlouva
router.post('/', verifyToken, requireRole('admin', 'smlouvy'), (req, res) => {
  const { name, counterparty, startDate, endDate, notes } = req.body;

  if (!name || !endDate) {
    return res.status(400).json({ error: 'Jméno a datum konce jsou povinné' });
  }

  const db = getDb();
  const id = uuid();

  db.run(
    `INSERT INTO contracts (id, name, counterparty, startDate, endDate, status, notes, createdAt, updatedAt) 
     VALUES (?, ?, ?, ?, ?, 'active', ?, datetime('now'), datetime('now'))`,
    [id, name, counterparty || null, startDate || null, endDate, notes || null],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      res.status(201).json({
        id,
        name,
        counterparty,
        startDate,
        endDate,
        status: 'active',
        notes
      });
    }
  );
});

// PUT úprava smlouvy
router.put('/:id', verifyToken, requireRole('admin', 'smlouvy'), (req, res) => {
  const { name, counterparty, startDate, endDate, status, notes } = req.body;

  if (!name || !endDate) {
    return res.status(400).json({ error: 'Jméno a datum konce jsou povinné' });
  }

  const db = getDb();

  db.run(
    `UPDATE contracts 
     SET name = ?, counterparty = ?, startDate = ?, endDate = ?, status = ?, notes = ?, updatedAt = datetime('now')
     WHERE id = ?`,
    [name, counterparty || null, startDate || null, endDate, status || 'active', notes || null, req.params.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (this.changes === 0) {
        return res.status(404).json({ error: 'Smlouva nenalezena' });
      }

      res.json({ success: true, message: 'Smlouva aktualizována' });
    }
  );
});

// DELETE smlouva
router.delete('/:id', verifyToken, requireRole('admin', 'smlouvy'), (req, res) => {
  const db = getDb();

  db.run('DELETE FROM contracts WHERE id = ?', [req.params.id], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (this.changes === 0) {
      return res.status(404).json({ error: 'Smlouva nenalezena' });
    }

    res.json({ success: true, message: 'Smlouva smazána' });
  });
});

// EXPORT smluv do CSV
router.get('/export/csv', verifyToken, requireRole('admin', 'smlouvy'), (req, res) => {
  const db = getDb();
  
  db.all('SELECT * FROM contracts ORDER BY endDate ASC', (err, contracts) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    const headers = ['Jméno', 'Protistrana', 'Začátek', 'Konec', 'Hodnotа', 'Poznámka', 'Stav'];
    const rows = contracts.map(c => [
      c.name,
      c.counterparty || '',
      c.startDate || '',
      c.endDate || '',
      c.value || '',
      c.notes || '',
      c.status
    ]);

    const csv = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=smlouvy.csv');
    res.send(csv);
  });
});

// IMPORT smluv z CSV
router.post('/import/csv', verifyToken, requireRole('admin'), (req, res) => {
  const db = getDb();
  const { data } = req.body;

  if (!data) {
    return res.status(400).json({ error: 'Žádná data' });
  }

  const lines = data.trim().split('\n');
  if (lines.length < 2) {
    return res.status(400).json({ error: 'Soubor je prázdný' });
  }

  const contracts = lines.slice(1).map(line => {
    const [name, counterparty, startDate, endDate, value, notes] = line.split(',').map(cell => cell.replace(/"/g, '').trim());
    return { name, counterparty: counterparty || null, startDate: startDate || null, endDate: endDate || null, value: value || null, notes: notes || null };
  });

  let imported = 0;
  let errors = 0;

  contracts.forEach(c => {
    if (!c.name) {
      errors++;
      return;
    }

    const id = require('uuid').v4();
    db.run(
      'INSERT INTO contracts (id, name, counterparty, startDate, endDate, value, status, notes, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, "active", ?, datetime("now"), datetime("now"))',
      [id, c.name, c.counterparty, c.startDate, c.endDate, c.value, c.notes],
      (err) => {
        if (!err) imported++;
        else errors++;
      }
    );
  });

  setTimeout(() => {
    res.json({ imported, errors, total: contracts.length });
  }, 500);
});

function calculateSeverity(endDate) {
  const daysUntil = Math.ceil((endDate - new Date()) / (1000 * 60 * 60 * 24));
  if (daysUntil < 0) return 'expired';
  if (daysUntil < 7) return 'critical';
  if (daysUntil < 30) return 'warning';
  return 'ok';
}

module.exports = router;
