const express = require('express');
const router = express.Router();
const { v4: uuid } = require('uuid');
const { getDb } = require('../database');
const authRoutes = require('./auth');

const verifyToken = authRoutes.verifyToken;
const requireRole = authRoutes.requireRole;

// GET všechna vozidla
router.get('/', verifyToken, (req, res) => {
  if (!['admin', 'auta'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Nemáš oprávnění vidět vozidla' });
  }

  const db = getDb();
  const { status, search } = req.query;

  let query = 'SELECT * FROM vehicles WHERE 1=1';
  const params = [];

  if (status) {
    query += ' AND status = ?';
    params.push(status);
  }

  if (search) {
    query += ' AND (spz LIKE ? OR brand LIKE ? OR model LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }

  query += ' ORDER BY brand, model ASC';

  db.all(query, params, (err, rows) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    // Přidej nextStk ke každému vozidlu
    let completed = 0;
    const vehiclesWithStk = rows.map(v => ({ ...v, nextStk: null }));

    if (rows.length === 0) {
      return res.json(vehiclesWithStk);
    }

    rows.forEach((vehicle, idx) => {
      db.get(
        'SELECT nextDue FROM vehicle_services WHERE vehicleId = ? AND type = "STK" ORDER BY nextDue ASC LIMIT 1',
        [vehicle.id],
        (err, stk) => {
          if (stk && stk.nextDue) {
            const daysUntil = Math.ceil((new Date(stk.nextDue) - new Date()) / (1000 * 60 * 60 * 24));
            vehiclesWithStk[idx].nextStk = daysUntil <= 0 ? `Po termínu: ${stk.nextDue}` : `${stk.nextDue}`;
          }
          
          completed++;
          if (completed === rows.length) {
            res.json(vehiclesWithStk);
          }
        }
      );
    });
  });
});

// GET vozidlo s jeho servisními údaji
router.get('/:id', verifyToken, (req, res) => {
  if (!['admin', 'auta'].includes(req.user.role)) {
    return res.status(403).json({ error: 'Nemáš oprávnění' });
  }

  const db = getDb();

  db.get('SELECT * FROM vehicles WHERE id = ?', [req.params.id], (err, vehicle) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (!vehicle) {
      return res.status(404).json({ error: 'Vozidlo nenalezeno' });
    }

    // Vezmi servisní údaje
    db.all('SELECT * FROM vehicle_services WHERE vehicleId = ? ORDER BY nextDue ASC', [req.params.id], (err, services) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      // Přidej daysUntil ke každému service
      services = services.map(s => ({
        ...s,
        daysUntil: Math.ceil((new Date(s.nextDue) - new Date()) / (1000 * 60 * 60 * 24)),
        severity: calculateSeverity(new Date(s.nextDue))
      }));

      res.json({
        ...vehicle,
        services
      });
    });
  });
});

// POST nové vozidlo
router.post('/', verifyToken, requireRole('admin', 'auta'), (req, res) => {
  const { spz, brand, model, year, vin, purchaseDate, purchasePrice, currentKm } = req.body;

  if (!spz || !brand || !model) {
    return res.status(400).json({ error: 'SPZ, značka a model jsou povinné' });
  }

  const db = getDb();
  const id = uuid();

  db.run(
    `INSERT INTO vehicles (id, spz, brand, model, year, vin, purchaseDate, purchasePrice, currentKm, status, createdAt, updatedAt) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', datetime('now'), datetime('now'))`,
    [id, spz, brand, model, year || null, vin || null, purchaseDate || null, purchasePrice || null, currentKm || 0],
    function(err) {
      if (err) {
        if (err.message.includes('UNIQUE')) {
          return res.status(400).json({ error: 'Vozidlo s touto SPZ již existuje' });
        }
        return res.status(500).json({ error: err.message });
      }

      res.status(201).json({ id, spz, brand, model, year, vin, purchaseDate, purchasePrice, currentKm });
    }
  );
});

// PUT úprava vozidla
router.put('/:id', verifyToken, requireRole('admin', 'auta'), (req, res) => {
  const { spz, brand, model, year, vin, purchaseDate, purchasePrice, currentKm, status } = req.body;

  if (!spz || !brand || !model) {
    return res.status(400).json({ error: 'SPZ, značka a model jsou povinné' });
  }

  const db = getDb();

  db.run(
    `UPDATE vehicles 
     SET spz = ?, brand = ?, model = ?, year = ?, vin = ?, purchaseDate = ?, purchasePrice = ?, currentKm = ?, status = ?, updatedAt = datetime('now')
     WHERE id = ?`,
    [spz, brand, model, year || null, vin || null, purchaseDate || null, purchasePrice || null, currentKm || 0, status || 'active', req.params.id],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (this.changes === 0) {
        return res.status(404).json({ error: 'Vozidlo nenalezeno' });
      }

      res.json({ success: true, message: 'Vozidlo aktualizováno' });
    }
  );
});

// DELETE vozidlo
router.delete('/:id', verifyToken, requireRole('admin', 'auta'), (req, res) => {
  const db = getDb();

  // Smaž i servisní údaje
  db.run('DELETE FROM vehicle_services WHERE vehicleId = ?', [req.params.id], (err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    db.run('DELETE FROM vehicles WHERE id = ?', [req.params.id], function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (this.changes === 0) {
        return res.status(404).json({ error: 'Vozidlo nenalezeno' });
      }

      res.json({ success: true, message: 'Vozidlo smazáno' });
    });
  });
});

// POST servisní údaj (STK, pojištění, atd)
router.post('/:id/services', verifyToken, requireRole('admin', 'auta'), (req, res) => {
  const { type, nextDue, lastDate, nextKm, currentKm, validFrom, validTo, cost, provider, notes } = req.body;

  if (!type || !nextDue) {
    return res.status(400).json({ error: 'Typ a datum jsou povinné' });
  }

  const db = getDb();
  const serviceId = uuid();

  db.run(
    `INSERT INTO vehicle_services (id, vehicleId, type, nextDue, lastDate, nextKm, currentKm, validFrom, validTo, cost, provider, notes, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))`,
    [serviceId, req.params.id, type, nextDue, lastDate || null, nextKm || null, currentKm || null, validFrom || null, validTo || null, cost || null, provider || null, notes || null],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      res.status(201).json({ id: serviceId, type, nextDue, lastDate, nextKm, currentKm, validFrom, validTo, cost, provider, notes });
    }
  );
});

// PUT aktualizace servisního údaje
router.put('/:vehicleId/services/:serviceId', verifyToken, requireRole('admin', 'auta'), (req, res) => {
  const { type, nextDue, lastDate, nextKm, currentKm, validFrom, validTo, cost, provider, notes } = req.body;

  if (!type || !nextDue) {
    return res.status(400).json({ error: 'Typ a datum jsou povinné' });
  }

  const db = getDb();

  db.run(
    `UPDATE vehicle_services 
     SET type = ?, nextDue = ?, lastDate = ?, nextKm = ?, currentKm = ?, validFrom = ?, validTo = ?, cost = ?, provider = ?, notes = ?
     WHERE id = ? AND vehicleId = ?`,
    [type, nextDue, lastDate || null, nextKm || null, currentKm || null, validFrom || null, validTo || null, cost || null, provider || null, notes || null, req.params.serviceId, req.params.vehicleId],
    function(err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (this.changes === 0) {
        return res.status(404).json({ error: 'Servis nenalezen' });
      }

      res.json({ success: true, message: 'Servis aktualizován' });
    }
  );
});

// DELETE servisní údaj
router.delete('/:vehicleId/services/:serviceId', verifyToken, requireRole('admin', 'auta'), (req, res) => {
  const db = getDb();

  db.run('DELETE FROM vehicle_services WHERE id = ? AND vehicleId = ?', [req.params.serviceId, req.params.vehicleId], function(err) {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    if (this.changes === 0) {
      return res.status(404).json({ error: 'Servis nenalezen' });
    }

    res.json({ success: true, message: 'Servis smazán' });
  });
});

// UPLOAD fotky vozidla
router.post('/:id/upload-photo', verifyToken, requireRole('admin', 'auta'), (req, res) => {
  const multer = require('multer');
  const path = require('path');
  
  const storage = multer.diskStorage({
    destination: path.join(__dirname, '../../uploads'),
    filename: (req, file, cb) => {
      cb(null, 'vehicle-' + req.params.id + '-' + Date.now() + path.extname(file.originalname));
    }
  });

  const upload = multer({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
      const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
      if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
      } else {
        cb(new Error('Pouze obrázky'));
      }
    }
  }).single('photo');

  upload(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'Žádný soubor' });
    }

    const db = getDb();
    const photoPath = `/uploads/${req.file.filename}`;

    db.run(
      'UPDATE vehicles SET attachmentPath = ? WHERE id = ?',
      [photoPath, req.params.id],
      function(err) {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        res.json({ success: true, photoPath });
      }
    );
  });
});

// EXPORT vozidel do CSV
router.get('/export/csv', verifyToken, requireRole('admin', 'auta'), (req, res) => {
  const db = getDb();
  
  db.all('SELECT * FROM vehicles ORDER BY brand, model', (err, vehicles) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }

    // Vytvoř CSV
    const headers = ['SPZ', 'Značka', 'Model', 'Rok', 'VIN', 'Nákup', 'Cena nákupu', 'Km nájezd', 'Stav'];
    const rows = vehicles.map(v => [
      v.spz,
      v.brand,
      v.model,
      v.year || '',
      v.vin || '',
      v.purchaseDate || '',
      v.purchasePrice || '',
      v.currentKm || '',
      v.status
    ]);

    const csv = [headers, ...rows].map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=vozidla.csv');
    res.send(csv);
  });
});

// IMPORT vozidel z CSV
router.post('/import/csv', verifyToken, requireRole('admin'), (req, res) => {
  const db = getDb();
  const { data } = req.body; // CSV data jako string

  if (!data) {
    return res.status(400).json({ error: 'Žádná data' });
  }

  const lines = data.trim().split('\n');
  if (lines.length < 2) {
    return res.status(400).json({ error: 'Soubor je prázdný' });
  }

  // Přeskoč header
  const vehicles = lines.slice(1).map(line => {
    const [spz, brand, model, year, vin, purchaseDate, purchasePrice, currentKm] = line.split(',').map(cell => cell.replace(/"/g, '').trim());
    return { spz, brand, model, year: year || null, vin: vin || null, purchaseDate: purchaseDate || null, purchasePrice: purchasePrice || null, currentKm: currentKm || 0 };
  });

  let imported = 0;
  let errors = 0;

  vehicles.forEach(v => {
    if (!v.spz || !v.brand || !v.model) {
      errors++;
      return;
    }

    const id = require('uuid').v4();
    db.run(
      'INSERT INTO vehicles (id, spz, brand, model, year, vin, purchaseDate, purchasePrice, currentKm, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "active", datetime("now"), datetime("now"))',
      [id, v.spz, v.brand, v.model, v.year, v.vin, v.purchaseDate, v.purchasePrice, v.currentKm],
      (err) => {
        if (!err) imported++;
        else errors++;
      }
    );
  });

  setTimeout(() => {
    res.json({ imported, errors, total: vehicles.length });
  }, 500);
});

function calculateSeverity(date) {
  const daysUntil = Math.ceil((date - new Date()) / (1000 * 60 * 60 * 24));
  if (daysUntil < 0) return 'expired';
  if (daysUntil < 14) return 'critical';
  if (daysUntil < 60) return 'warning';
  return 'ok';
}

module.exports = router;
