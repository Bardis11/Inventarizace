const config = require('./config');

const levels = {
  error: 0,
  warn: 1,
  info: 2,
  debug: 3
};

const colors = {
  error: '\x1b[31m', // Red
  warn: '\x1b[33m',  // Yellow
  info: '\x1b[36m',  // Cyan
  debug: '\x1b[35m', // Magenta
  reset: '\x1b[0m'
};

class Logger {
  constructor(name = 'App') {
    this.name = name;
    this.level = levels[config.logging.level] || levels.info;
  }

  log(level, message, data = null) {
    if (levels[level] > this.level) return;

    const timestamp = new Date().toISOString();
    const color = colors[level] || '';
    const reset = colors.reset;
    
    let output = `${color}[${timestamp}] [${level.toUpperCase()}] [${this.name}] ${message}${reset}`;
    
    if (data) {
      output += `\n${JSON.stringify(data, null, 2)}`;
    }

    console.log(output);
  }

  error(message, data) { this.log('error', message, data); }
  warn(message, data) { this.log('warn', message, data); }
  info(message, data) { this.log('info', message, data); }
  debug(message, data) { this.log('debug', message, data); }
}

module.exports = Logger;
